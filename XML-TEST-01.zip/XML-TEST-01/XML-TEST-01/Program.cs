﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace XML_TEST_01
{
    class Program
    {
        static void Main(string[] args)
        {
            XmlReader xmlreader = XmlReader.Create("http://www.ecb.int/stats/eurofxref/eurofxref-daily.xml"); //Read Xml File from Link , From dynamic Link //
            while (xmlreader.Read()) // If don't use while, it will read only the first Line //
            {
                if((xmlreader.NodeType == XmlNodeType.Element) && (xmlreader.Name == "Cube")) // Check if Element Cube is exsist //
                {
                    if(xmlreader.HasAttributes)
                        Console.WriteLine(xmlreader.GetAttribute("currency") + ";" + xmlreader.GetAttribute("rate")); // Find if Attribute of Cube which is Currency and Rate Exist //
                }
                
            }
            Console.ReadKey();
        }
    }
}




